#ifndef JAVA_COMMAND_H
#define JAVA_COMMAND_H

#include <stdlib.h>
#include <stdio.h>

// Function declarations (if any) can go here
int run_command();

#endif // JAVA_COMMAND_H
