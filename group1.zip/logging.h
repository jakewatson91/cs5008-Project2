#ifndef LOGGING_H
#define LOGGING_H

#include <stdlib.h>
#include <stdio.h>

// Function declarations (if any) can go here
int logging(char *hostname);

#endif // LOGGING_H
